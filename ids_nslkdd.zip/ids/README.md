# Détection d'intrusions par apprentissage automatique sur NSL-KDD
### Une évaluation sous décalage de distribution et face aux attaques inédites

Projet reproductible accompagnant le rapport. Chaque chiffre du rapport est produit par
les scripts ci-dessous ; aucun n'est saisi à la main.

## Structure

```
ids/
├── data/raw/                  KDDTrain+, KDDTest+, KDDTest-21 (téléchargés, cf. ci-dessous)
├── src/
│   ├── nslkdd.py              chargement, taxonomie DARPA, prétraitement sans fuite
│   ├── models.py              5 modèles supervisés + 2 détecteurs d'anomalies
│   ├── 01_eda.py              diagnostic du jeu de données (décalage, attaques inédites…)
│   ├── 02_experiments.py      entraînement (5 graines), prédictions sauvegardées
│   ├── 03_analysis.py         métriques, IC bootstrap, McNemar-Holm, calibration, figures
│   ├── 04_leave_attack_out.py simulation de zero-day à l'intérieur du train
│   ├── 05_explain_ablation.py SHAP + ablation par groupes de variables
│   ├── 06_host_ablation_per_type.py  effet par type du retrait des variables host-based
│   └── 99_verify_report.py    recalcule les chiffres cités dans le rapport
└── results/                   JSON/CSV de résultats + figures/
```

## Reproduire

```bash
pip install scikit-learn==1.9.1 lightgbm==4.7.0 shap==0.54.1 pandas numpy scipy matplotlib
mkdir -p data/raw && cd data/raw
for f in KDDTrain+.txt KDDTest+.txt KDDTest-21.txt; do
  curl -sSfLO "https://raw.githubusercontent.com/jmnwong/NSL-KDD-Dataset/master/$f"; done
cd ../..
python src/01_eda.py && python src/02_experiments.py && python src/03_analysis.py
python src/04_leave_attack_out.py && python src/05_explain_ablation.py
python src/06_host_ablation_per_type.py && python src/99_verify_report.py   # contrôle des chiffres du rapport
```

Empreintes SHA-256 des fichiers utilisés (contrôle d'intégrité) :

| Fichier | Lignes | SHA-256 |
|---|---|---|
| KDDTrain+.txt | 125 973 | `1b86d2f957b33082081bba410fe129b475efebcc13c9014c3f447c8271aadf95` |
| KDDTest+.txt | 22 544 | `fa46b0935342616aa83b7c2578db355b6a7aaabbc492248172c7a1e8b7ab8f84` |
| KDDTest-21.txt | 11 850 | `746993ac9e25868827cacf09eab450050a2a1056e1ce48a1ad39f5dc801d531d` |

Matériel de référence : 2 vCPU, 7 Go RAM, aucun GPU — durée totale ≈ 1 h 30.

## Garde-fous méthodologiques

1. **Aucune fuite** : encodage et normalisation appris sur le train seul (`sklearn.Pipeline`) ;
   la colonne `difficulty` n'est jamais une variable explicative.
2. **Aucune décision prise sur le test** : seuils et choix de modèle viennent de la validation
   croisée hors-pli ou d'une validation interne au train.
3. **Incertitude quantifiée** : 5 graines, IC bootstrap à 95 %, test de McNemar exact avec
   correction de Holm.
4. **Évaluation désagrégée** : attaques vues vs inédites, par type, KDDTest+ et KDDTest-21.

## Passer à CIC-IDS2017

Le pipeline est générique : il suffit de réécrire `load()` et la liste des variables
dans `nslkdd.py`. Avant de le faire, lire Engelen et al. (2021) et Lanvin et al. (2022),
qui documentent des erreurs d'étiquetage et de génération de flux dans la version
originale de CIC-IDS2017 ; utiliser la version corrigée, et découper train/test **par
jour de capture** et non aléatoirement, sous peine de reproduire l'illusion décrite
à la section 5.2 du rapport.
